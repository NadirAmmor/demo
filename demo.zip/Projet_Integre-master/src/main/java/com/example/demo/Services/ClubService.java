package com.example.demo.Services;

import com.example.demo.daos.ClubDao;

public interface ClubService {


}
