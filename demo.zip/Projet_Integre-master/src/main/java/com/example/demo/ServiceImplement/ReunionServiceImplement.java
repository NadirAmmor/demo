package com.example.demo.ServiceImplement;

import com.example.demo.Services.ReunionService;

public class ReunionServiceImplement implements ReunionService {
}
