package com.example.demo.ServiceImplement;

import com.example.demo.Services.EvenementService;

public class EvenementServiceImplement implements EvenementService {
}
