package com.example.demo.Services;

public interface EvenementService {
}
