package com.example.demo.ServiceImplement;

import com.example.demo.Services.TransactionService;

public class TransactionServiceImplement implements TransactionService {
}
