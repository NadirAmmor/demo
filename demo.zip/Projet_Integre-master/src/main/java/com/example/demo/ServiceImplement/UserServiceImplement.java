package com.example.demo.ServiceImplement;

import com.example.demo.Services.UserService;

public class UserServiceImplement implements UserService {
    
}
