package com.example.demo.Reposotory;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ReunionReposotory extends JpaRepository {
}
