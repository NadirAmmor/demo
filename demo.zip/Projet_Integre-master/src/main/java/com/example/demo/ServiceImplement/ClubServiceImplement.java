package com.example.demo.ServiceImplement;

import com.example.demo.Services.ClubService;

public class ClubServiceImplement implements ClubService {
}
