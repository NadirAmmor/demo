package com.example.demo.ServiceImplement;

import com.example.demo.Services.EtudiantService;

public class EtudiantServiceImplement implements EtudiantService {

}
