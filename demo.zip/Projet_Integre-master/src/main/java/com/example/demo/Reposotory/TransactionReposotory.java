package com.example.demo.Reposotory;

import org.springframework.data.jpa.repository.JpaRepository;

public interface TransactionReposotory extends JpaRepository {
}
