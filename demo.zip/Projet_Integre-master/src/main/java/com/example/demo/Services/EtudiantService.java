package com.example.demo.Services;

import org.springframework.stereotype.Service;

@Service
public interface EtudiantService {
}
